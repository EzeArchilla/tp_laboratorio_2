﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Entidades
{
    public static class PaqueteDAO
    {
        private static SqlCommand comando;
        private static SqlConnection conexion;

        /// <summary>
        /// Inserta un paquete en la BD
        /// </summary>
        /// <param name="p">Paquete a insertar</param>
        /// <returns>retorna false si ocurrio un error</returns>
        public static bool Insertar(Paquete p)
        {
            String connectionStr = "Data Source=.\\SQLEXPRESS;Initial Catalog =correo-sp-2017; Integrated Security = True";

            try
            {
                comando = new SqlCommand();
                conexion = new SqlConnection(connectionStr);

                comando.CommandType = System.Data.CommandType.Text;
                comando.Connection = conexion;

                StringBuilder str = new StringBuilder();
                str.Append("INSERT INTO Paquetes (direccionEntrega,trackingID,alumno) VALUES(");
                str.Append("'" + p.DireccionEntrega + "',");
                str.Append("'" + p.TrackingID + "',");
                str.Append("'Ezequiel Archilla')");

                comando.CommandText = str.ToString();

                conexion.Open();

                comando.ExecuteNonQuery();

                conexion.Close();

                return true;
            }
            catch(Exception ex)
            {
                conexion.Close();
                return false;
            }
        }
    }
}
