using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Entidades.Excepciones;

namespace MainCorreo
{
  public partial class frmPpal : Form
  {
    Correo correo;
    public frmPpal()
    {
      InitializeComponent();
      correo = new Correo();
      Paquete.eventoErrorConexion += this.MensajeErrorCargaBD;
    }

    /// <summary>
    /// Agrega paquete al correo y actualiza los estados
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void BtnAgregar_Click(object sender, EventArgs e)
    {
      Paquete paquete = new Paquete(txtDireccionEntrega.Text, mtxtTrackingID.Text);
      paquete.InformaEstado += paq_InformaEstado;

      try
      {
        correo = correo + paquete;
      }
      catch (TrackingIdRepetidoException ex)
      {
        String mensaje = "El Tracking ID " + paquete.TrackingID + " ya figura en la lista de envios.";
        MessageBox.Show(mensaje, "Paquete repetido", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }

      ActualizarEstados();
    }

    private void paq_InformaEstado(object sender, EventArgs e)
    {
      if (this.InvokeRequired)
      {
        Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
        this.Invoke(d, new object[] { sender, e });
      }
      else
      {
        ActualizarEstados();
      }
    }

    /// <summary>
    /// Limpia los ListBox y escribe la informacion actualizada en cual corresponda
    /// </summary>
    public void ActualizarEstados()
    {
      lstEstadoIngresado.Items.Clear();
      lstEstadoEnViaje.Items.Clear();
      lstEstadoEntregado.Items.Clear();

      foreach (Paquete paquete in this.correo.Paquete)
      {
        switch (paquete.Estado)
        {
          case EEstado.Ingresado:
            lstEstadoIngresado.Items.Add(paquete);
            break;
          case EEstado.EnViaje:
            lstEstadoEnViaje.Items.Add(paquete);
            break;
          case EEstado.Entregado:
            lstEstadoEntregado.Items.Add(paquete);
            break;
        }
      }
    }

    /// <summary>
    /// Mata los hilos activos
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void Formulario_FormClosing(object sender, FormClosingEventArgs e)
    {
      correo.FinEntregas();
    }

    private void BtnMostrarTodos_Click(object sender, EventArgs e)
    {
      this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
    }

    private void MostrarInformacion<T>(IMostrar<T> elemento)
    {
      if (!Object.Equals(elemento, null))
      {
        /*
        if (elemento is Paquete)
          this.rtbMostrar.Text = ((Paquete)elemento).MostrarDatos((Paquete)elemento);
        else if (elemento is Correo)
          this.rtbMostrar.Text = ((Correo)elemento).MostrarDatos((Correo)elemento);
        if (!(elemento is null))
      {*/

        rtbMostrar.Text = elemento.MostrarDatos(elemento);
        
        String salida = rtbMostrar.Text;
        
        salida.Guardar("salida.txt");
      }
    }

    private void MensajeErrorCargaBD()
    {
      MessageBox.Show("Error de conexion a la base de datos", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }


    private void MostrarToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
      //this.MostrarInformacion<Paquete>((Paquete)lstEstadoEntregado.SelectedItem.ToString());
    }


  }
}
